# Session 3 — Backend & Real Data

Sample data for connecting your Next.js dashboard to a real Supabase database.

## What's inside

**`sample-data-session-3.xlsx`** — One Excel workbook, six sheets. A complete fictional Saudi retail business called **Noor Trading Co.** (1 year of operations, SAR currency).

| Sheet      | Records | What's in it                                        |
| ---------- | ------- | --------------------------------------------------- |
| Sales      | 144     | 12 months of orders — date, customer, product, amount, status, payment |
| Customers  | 33      | Names, emails, lifetime value, signup dates        |
| Products   | 50      | Catalog: prices, categories, SKUs, current stock   |
| Expenses   | 104     | Rent, salaries, marketing, utilities by month      |
| Inventory  | 55      | Stock levels, reorder points, supplier info        |
| Feedback   | 36      | Customer ratings and comments                      |

Total: ~420 records across six related tables.

## How to use it

1. Drop this `xlsx` file into your Next.js project folder (or anywhere Claude Code can read it).
2. Make sure the Supabase MCP is connected (Session 3 walks you through this).
3. In Claude Code, run a single prompt like:

   > Look at the file `sample-data-session-3.xlsx`. Create tables in my Supabase database for every sheet, and load all of the data using the Supabase MCP.

4. Watch Claude Code design the schema, create tables, and load all six sheets — without you writing any SQL.
5. Verify in the Supabase Table Editor that all six tables exist and contain rows.
6. Now ask your data questions in plain English — see the "Question Types & Patterns" slide for ideas.

## Notes

- All amounts are in Saudi Riyal (SAR).
- Customer names and product categories are deliberately Saudi-flavored (abayas, dates, oud, Arabic coffee sets).
- Some rows are intentionally messy — missing customer names, returned orders — so your queries handle real-world data.
- After class, swap this file for your own business data and repeat the same workflow.

— Ingenuity Labs
