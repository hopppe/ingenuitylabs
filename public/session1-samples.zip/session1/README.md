# Session 1 — Sample Files for Hands-On Exercises

These files are the inputs for the Session 1 hands-on exercises.

**Download:** [ingenuitylabs.net/session1-samples.zip](https://ingenuitylabs.net/session1-samples.zip)

Unzip it and put the `session1/` folder inside an `ai-course` folder:

- Mac: `~/Documents/ai-course/session1/`
- Windows: `Documents\ai-course\session1\`

Then in Cowork, click **Add folder** and pick your `ai-course` folder.

## What's in here

| Folder | Used in exercise | What it's for |
|---|---|---|
| `messy-folder/` | Exercise 1 — File management with Cowork | An intentionally messy folder of mixed files (receipts, screenshots, notes, a CSV). You'll have Cowork clean it up. |
| `cowork-deliverable/` | Exercise 2 — Create a deck and a spreadsheet | A product brief and a CSV of sales data. You'll have Cowork turn these into a PowerPoint and an Excel workbook. |
| `chrome-exercise/` | Exercise 4 — Chrome extension filling a form | A company profile. You'll give it to Claude in Chrome and have it fill the form at ingenuitylabs.net/aiclass-form. |
| `claude-code-exercise/` | (Session 2 preview) | A company brief for a future Claude Code exercise. |

Exercise 3 (Gmail connector) works against your real inbox — no local file needed.
