# Al-Noor Logistics — Company Brief

**Use this file as input for the Claude Code hands-on in Session 1.**

## About the company
Al-Noor Logistics is a mid-sized Saudi logistics firm headquartered in Riyadh, founded in 2014. It handles last-mile delivery and warehousing for e-commerce retailers across the GCC.

## Key facts
- Founded: 2014
- HQ: Riyadh, Saudi Arabia
- Employees: 280
- Fleet: 140 vehicles
- Warehouses: 6 (Riyadh, Jeddah, Dammam, Mecca, Medina, Abha)
- Clients: 60+ e-commerce brands including three of the top-10 Saudi retailers

## What they do
- Last-mile delivery (same-day and next-day)
- Temperature-controlled storage
- Cross-border shipping to UAE, Kuwait, Bahrain
- Returns handling and reverse logistics

## Services & pricing (example)
| Service | Starting price (SAR) |
|---|---|
| Same-day delivery (Riyadh) | 15 |
| Next-day delivery (nationwide) | 22 |
| Cross-border (GCC) | 45 |
| Temperature-controlled storage | 180 / pallet / month |
| Returns handling | 8 / parcel |

## Contact
- Phone: +966 11 555 0140
- Email: hello@alnoor-logistics.example
- Website: alnoor-logistics.example

## Brand tone
Professional, efficient, warm. Bilingual Arabic / English. Green and navy color palette.
