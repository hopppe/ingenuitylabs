# Product Brief — "Mizan" AI Expense Analyzer

**Use this file as input for the Cowork hands-on in Session 1.**
You'll ask Cowork to turn this brief into a 10-slide pitch deck (.pptx).

## Product name
Mizan (Arabic for "balance / scales")

## One-line description
An AI-powered expense analyzer that reads receipts and invoices from your Gmail and WhatsApp, categorizes them, and gives Saudi SMBs a real-time P&L.

## The problem
Saudi small and medium businesses lose an average of 8–12% of net income to unclassified and unreconciled expenses. Most owners do their books in Excel once a month, which is too late to act on. Receipts live in email, WhatsApp, and paper — there's no single source of truth.

## The solution
Mizan connects to Gmail, WhatsApp Business, and bank statements, uses AI to extract line items from receipts (in Arabic and English), auto-categorizes them, and produces a live P&L and cash-flow view. Owners get a daily summary in Arabic at 7am.

## Target customer
- Saudi SMBs with 5–50 employees
- Annual revenue 2M – 30M SAR
- Industries: retail, F&B, professional services, light manufacturing
- Primary buyer: owner or GM; secondary: bookkeeper

## Market opportunity
- 1.1M registered SMBs in KSA (2025)
- ~180K meet our target profile
- Saudi SME accounting software market: ~2.4B SAR by 2028
- Vision 2030 tailwinds: digitization of SME sector, ZATCA e-invoicing mandate

## Pricing
- Starter: 299 SAR / month (up to 200 transactions)
- Growth: 799 SAR / month (up to 1,500 transactions)
- Enterprise: 2,499 SAR / month (unlimited + multi-entity)

## Traction (example numbers for the deck)
- 47 pilot customers
- 92% month-1 retention
- Average customer saves 11 hours/month of bookkeeping
- NPS: 64

## Competitive landscape
- Zoho Books, QuickBooks — strong in bookkeeping, weak at receipt capture, no Arabic
- Qoyod — local, but manual entry heavy
- Mizan's edge: end-to-end automation + Arabic-first UX + WhatsApp integration

## Team
Three co-founders: ex-STC product lead, ex-SAMA regulatory, ex-Careem engineering.

## The ask
Raising 8M SAR seed to expand sales team, add ZATCA e-invoicing integration, and reach 1,000 paying customers by end of 2026.

## Brand
- Colors: deep green (#0d3028), sand (#f4e5c2), white
- Tone: clear, confident, bilingual
