# Services Agreement — DRAFT v3 FINAL (probably)

**Between:** Mizan Financial Technologies ("Service Provider")
**And:** [CLIENT NAME — FILL IN] ("Client")
**Effective date:** [FILL IN]

## 1. Services
Service Provider shall provide the Mizan AI Expense Analyzer platform, including: Gmail and WhatsApp receipt ingestion, AI categorization, real-time P&L dashboard, daily Arabic summary, and up to 1,500 transactions per month.

## 2. Fees
- Monthly subscription: 799 SAR + VAT
- Setup fee (one-time): 1,500 SAR + VAT
- Overage: 0.80 SAR per transaction above 1,500

## 3. Term
Initial term: 12 months. Auto-renews annually unless either party gives 60 days' written notice.

## 4. Termination
Either party may terminate for material breach with 30 days' cure period. Client may terminate for convenience after month 6 with 60 days' notice.

## 5. Data & privacy
- Service Provider will not train AI models on Client data.
- All data stored in KSA (SDAIA-compliant region).
- Client retains full ownership.

## 6. Confidentiality
Standard mutual NDA clauses.

## 7. Governing law
Kingdom of Saudi Arabia. Any disputes heard in Riyadh commercial court.

---
Status: awaiting legal review — DO NOT SEND
Last edited: 2026-03-30 by Layla
