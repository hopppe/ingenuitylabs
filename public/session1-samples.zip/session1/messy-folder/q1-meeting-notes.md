# Q1 Team Meeting — 2026-03-28

Attendees: Faisal, Noura, Layla, Omar, Ethan

## Numbers
- Q1 revenue: ~1.2M SAR (target was 1.0M)
- New customers: 47
- Churn: 2.1% — slightly up from 1.8% last quarter

## Wins
- Enterprise deal with Al-Bader Group (signed Feb 20)
- Won RFP against Qoyod for 3 mid-market accounts
- Noura closed 11 Starter Plan deals in February — personal record

## Concerns
- Pipeline coverage for Q2 is thin — only 1.4x
- Engineering: ZATCA e-invoicing feature slipping to Q3
- Support ticket volume up 30% month-over-month

## Action items
- [ ] Faisal: refresh Q2 pipeline by end of next week
- [ ] Layla: hire another SDR (req already posted)
- [ ] Omar: weekly eng ↔ support sync to reduce tickets
- [ ] Ethan: investor update by April 10

## Next meeting: 2026-04-11
