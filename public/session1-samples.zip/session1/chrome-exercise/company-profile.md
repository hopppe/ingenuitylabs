# Company Profile — Bayt Al-Hikma Holdings

**Use this profile for the Session 1 Chrome extension exercise.**
Open the AI Consultation Intake form at **ingenuitylabs.net/aiclass-form**, then give
this file to Claude in Chrome and ask it to fill in every field using this info —
but stop before hitting Submit so you can review.

---

## Company

- **Company name:** Bayt Al-Hikma Holdings
- **Industry:** Retail / E-commerce
- **Company size:** 51–250 employees (currently 184)
- **Annual revenue (SAR):** 25M – 100M (actual: 47.5M SAR in 2025)
- **City:** Riyadh (HQ); secondary office in Jeddah

Bayt Al-Hikma Holdings operates a network of 14 specialty bookstores across Saudi
Arabia, plus a growing e-commerce arm that launched in 2023. We focus on Arabic
literature, academic textbooks, and curated children's books.

## Primary contact

- **Full name:** Noura Al-Saud
- **Title / role:** Chief Operating Officer
- **Work email:** noura.alsaud@baythikma.example
- **Phone:** +966 11 555 0482

Noura has been with the company for 7 years. She previously led digital
transformation at a regional bank. She is the decision-maker on this engagement and
prefers direct, concise communication.

## What brings us in

### Primary business challenge
We sit on a huge amount of customer data from our 14 stores and our online shop, but
we can't use it. Our e-commerce arm is growing 40% year over year, but we're losing
repeat customers to Amazon and Jarir. We need AI to help us: (1) personalize book
recommendations for our online shoppers, (2) predict which titles will sell in which
cities so we stop overstocking in Riyadh and understocking in Jeddah, and (3) draft
bilingual (Arabic / English) marketing copy automatically so our small marketing
team can keep up with the weekly cadence we need.

### AI experience level
**Some** — the marketing team uses ChatGPT casually for blurbs and product
descriptions, but nothing systematic. No AI is integrated into our operations or
inventory systems yet.

### Timeline
**Within 3 months** — we want a working pilot before the academic-year back-to-school
rush in August.

### Budget range
**150K – 500K SAR** for the initial 12-month engagement, with option to expand.

### Additional notes
Vision 2030 alignment matters to us — our chairman sits on a regional retail council
and we want to be a case study for AI adoption in Saudi specialty retail. Data must
remain in KSA (we're SDAIA-conscious). Bilingual Arabic/English is non-negotiable —
any model we use must handle Arabic with real fluency, not just translation.

---

## Notes for Claude (when filling the form)

- Match the dropdown options as closely as possible (the form's dropdown values are
  defined — pick the closest match).
- For the "Primary business challenge" textarea, **summarize** the three challenges
  above in your own words — don't paste the whole paragraph. 2–3 sentences.
- Leave "Additional notes" to the point — mention Vision 2030, bilingual needs, and
  data residency.
- **Stop before clicking Submit.** The human reviewing the page will click Submit.
